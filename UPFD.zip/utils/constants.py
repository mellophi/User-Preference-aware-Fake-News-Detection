
ROOT_DIR = "X:/fakenewsnet_dataset"

DATASETS = ["gossipcop", "politifact"]
LABELS = ["fake", "real"]

PATH = {
    "GRAPH_FOLDER" : "{}/GRAPH/".format(ROOT_DIR)
}